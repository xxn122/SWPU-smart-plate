export default {
    isloaded: false,
    setloaded (newsit) {
      this.isloaded = newsit
      
    }
  }